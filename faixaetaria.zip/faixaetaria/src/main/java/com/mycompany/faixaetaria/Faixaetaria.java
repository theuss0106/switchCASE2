/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.faixaetaria;

/** 
 *
 * @author FATEC ZONA LESTE
 */


import java.util.Scanner;
public class Faixaetaria {
    public static void main(String[] args) {
      Scanner sc = new Scanner (System.in);
      try {
            System.out.print("Digite sua idade: ");
            int idade = sc.nextInt();
            int codigo;

            if (idade >= 0 && idade <= 12) {
                codigo = 1;
            } else if (idade <= 17) {
                codigo = 2;
            } else if (idade <= 59) {
                codigo = 3;
            } else {
                codigo = 4;
            }

            switch (codigo) {
                case 1 -> System.out.println("Criança (0 a 12 anos)");
                case 2 -> System.out.println("Adolescente (13 a 17 anos)");
                case 3 -> System.out.println("Adulto (18 a 59 anos)");
                case 4 -> System.out.println("Idoso (60+ anos)");
                default -> System.out.println("Idade invalida!");
            }
        } catch (Exception e) {
            System.out.println("Erro: entrada invalida!");
        } finally {
            sc.close();
            System.out.println("Programa finalizado.");
        }
    }
}