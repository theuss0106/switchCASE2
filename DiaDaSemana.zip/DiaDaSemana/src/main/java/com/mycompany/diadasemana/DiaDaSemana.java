/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.diadasemana;

import java.util.Scanner;

/**Matheus Sampaio. Esse é um projeto feito para o aprendizado do switch case em JAVA
 *
 * @author FATEC ZONA LESTE
 */



public class DiaDaSemana {
    
public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite um número de 1 a 7: ");
        int numero = scanner.nextInt();
        String dia;

        switch (numero) {
            case 1:
                dia = "Domingo";
                break;
            case 2:
                dia = "Segunda-feira";
                break;
            case 3:
                dia = "Terça-feira";
                break;
            case 4:
                dia = "Quarta-feira";
                break;
            case 5:
                dia = "Quinta-feira";
                break;
            case 6:
                dia = "Sexta-feira";
                break;
            case 7:
                dia = "Sábado";
                break;
            default:
                dia = "Dia inválido";
                break;
        }

        System.out.println("Dia da semana correspondente: " + dia);
        scanner.close();
    }
}