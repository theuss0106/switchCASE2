/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.tarifasdetransporte;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class DiaDaSemana {
    public static void main(String[] args) {
        
        
        
        
        
    }
    
}
