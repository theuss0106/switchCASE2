/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.jogofavorito;

/**Matheus Sampaio. Esse é um projeto feito para o aprendizado do switch case em JAVA
 *
 * @author FATEC ZONA LESTE
 */


import java.util.Scanner;

public class JogoFavorito {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite um número de 1 a 3: ");
        int numero = scanner.nextInt();
        String fruta;

        switch (numero) {
            case 1:
                fruta = "Maçã";
                break;
            case 2:
                fruta = "Banana";
                break;
            case 3:
                fruta = "Laranja";
                break;
            default:
                fruta = "Fruta inválida";
                break;
        }

        System.out.println("Fruta correspondente: " + fruta);
        scanner.close();
    }
}