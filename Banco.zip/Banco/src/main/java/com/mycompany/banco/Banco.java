/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.banco;

/**
 *
 * @author FATEC ZONA LESTE
 */

import java.util.Scanner;
public class Banco {
    public static void main(String[] args) {
      Scanner sc = new Scanner (System.in);
       double saldo = 1000.0; // saldo inicial

        try {
            System.out.println("Menu de Atendimento:");
            System.out.println("1 - Consultar saldo");
            System.out.println("2 - Sacar dinheiro");
            System.out.println("3 - Depositar dinheiro");
            System.out.println("4 - Encerrar atendimento");
            System.out.println("Digite aqui sua escolha: ");
            
            
            
            int opcao = sc.nextInt();

            switch (opcao) {
                case 1 -> System.out.println("Saldo atual: R$ " + saldo);
                case 2 -> {
                    System.out.print("Digite o valor do saque: ");
                    double saque = sc.nextDouble();
                    if (saque > saldo) {
                        System.out.println("Erro: saldo insuficiente!");
                    } else {
                        saldo -= saque;
                        System.out.println("Saque realizado! Saldo atual: R$ " + saldo);
                    }
                }
                case 3 -> {
                    System.out.print("Digite o valor do deposito: ");
                    double deposito = sc.nextDouble();
                    saldo += deposito;
                    System.out.println("Deposito realizado! Saldo atual: R$ " + saldo);
                }
                case 4 -> System.out.println("Atendimento encerrado.");
                default -> System.out.println("Opção invalida!");
            }
        } catch (Exception e) {
            System.out.println("Erro: entrada invalida!");
        } finally {
            sc.close();
            System.out.println("Programa finalizado.");
        }
    }
}