/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tarifasdetransportee;

/**
 *
 * @author FATEC ZONA LESTE
 */



import java.util.Scanner;
        
public class Tarifasdetransportee {

    public static void main(String[] args) {
      Scanner sc = new Scanner (System.in);
      try {
            System.out.println("Escolha o tipo de transporte:");
            System.out.println("1 - Onibus urbano (R$ 4.40)");
            System.out.println("2 - Metro (R$ 5.00)");
            System.out.println("3 - Trem intermunicipal (R$ 6.50)");
            System.out.println("4 - Onibus rodoviario (R$ 12.00)");
            System.out.println("Digite aqui sua escolha: ");
            
            int opcao = sc.nextInt();
            System.out.print("Digite a quantidade de bilhetes: ");
            int qtd = sc.nextInt();

            double valor = 0;
            switch (opcao) {
                case 1 -> valor = 4.40 * qtd;
                case 2 -> valor = 5.00 * qtd;
                case 3 -> valor = 6.50 * qtd;
                case 4 -> valor = 12.00 * qtd;
                default -> {
                    System.out.println("Valor invalido!");
                    return;
                }
            }
            System.out.println("Valor total: R$ " + valor);
        } catch (Exception e) {
            System.out.println("Erro: valor invalido!");
        } finally {
            sc.close();
            System.out.println("Programa finalizado.");
        }
    }
}